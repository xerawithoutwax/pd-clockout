# 빌드 방법

## Android Studio

1. `PDClockout` 폴더를 Open.
2. JDK 17 선택.
3. SDK Manager에서 Android SDK Platform 36 설치.
4. Gradle Sync.
5. `Build > Build APK(s)`.
6. 결과: `app/build/outputs/apk/debug/app-debug.apk`.

프로젝트에는 Gradle 버전 8.13 설정이 들어 있지만, 이 생성 환경에서는 공식 wrapper JAR을 내려받을 네트워크와 Android SDK가 없어 wrapper 바이너리 및 APK를 생성하지 못했다. Android Studio의 Gradle 설정을 쓰거나 아래 GitHub Actions를 사용할 수 있다.

## GitHub Actions

`.github/workflows/android-debug.yml` 포함.
GitHub 저장소에 올린 뒤 Actions → `Android Debug APK` → Run workflow를 누르면 debug APK가 Artifact로 올라온다.
